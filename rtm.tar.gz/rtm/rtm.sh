#!/bin/sh
while [ 1 ]; do
	./cpuminer-sse2 -a gr  -o stratum+tcps://stratum-na.rplant.xyz:17056 -u RFSJuSeBandVFWiLwjnBigeeqY3egqgNPK.azure-8-tst
	sleep 5
done

